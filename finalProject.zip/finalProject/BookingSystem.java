package finalProject;

import java.util.*;

class BookingSystem {
    static class Booking {
        String name, service;
        int slot;

        Booking(String name, String service, int slot) {
            this.name = name;
            this.service = service;
            this.slot = slot;
        }

        @Override
        public String toString() {
            return "Name: " + name + " | Service: " + service + " | Slot: " + slot;
        }
    }

    private static final List<Booking> bookings = new ArrayList<>();
    private static final Set<Integer> bookedSlots = new HashSet<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void bookSlot() {
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        System.out.print("Enter service name: ");
        String service = scanner.nextLine();
        System.out.print("Enter slot number (1-10): ");
        int slot = scanner.nextInt();
        scanner.nextLine();

        if (bookedSlots.contains(slot)) {
            System.out.println("Slot already booked! Choose another slot.");
        } else {
            bookings.add(new Booking(name, service, slot));
            bookedSlots.add(slot);
            System.out.println("Booking successful!");
        }
    }

    public static void cancelBooking() {
        displayBookings();
        System.out.print("Enter slot number to cancel: ");
        int slot = scanner.nextInt();
        scanner.nextLine();

        bookings.removeIf(booking -> booking.slot == slot);
        bookedSlots.remove(slot);
        System.out.println("Booking canceled.");
    }

    public static void displayBookings() {
        if (bookings.isEmpty()) {
            System.out.println("No bookings available.");
            return;
        }
        System.out.println("\nCurrent Bookings:");
        for (Booking booking : bookings) {
            System.out.println(booking);
        }
    }

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nOnline Booking System");
            System.out.println("1. Book a Slot");
            System.out.println("2. Cancel Booking");
            System.out.println("3. View All Bookings");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> bookSlot();
                case 2 -> cancelBooking();
                case 3 -> displayBookings();
                case 4 -> {
                    System.out.println("Exiting... Thank you!");
                    return;
                }
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
