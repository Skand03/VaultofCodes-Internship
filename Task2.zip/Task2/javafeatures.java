class javaFeatures {
    public static void main(String[] args) {
        int number = 10;
        String message = "Welcome to vaultOfCodesInternship";

        try {
            int result = number / 0;
            System.out.println(result);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println(message);
    }
}
