import java.io.*;

class fileHandling {
    public static void main(String[] args) throws IOException {
        String filename = "example.txt";
        FileWriter writer = new FileWriter(filename);
        writer.write("Hello, this is my file.");
        writer.close();

        BufferedReader reader = new BufferedReader(new FileReader(filename));
        System.out.println(reader.readLine());
        reader.close();
    }
}