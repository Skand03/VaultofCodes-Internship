class Palindrome {
    public static void main(String[] args) {
        String word = "madam";
        String reversed = new StringBuilder(word).reverse().toString();
        System.out.println(word.equalsIgnoreCase(reversed) ? "Palindrome" : "Not a Palindrome");
    }
}