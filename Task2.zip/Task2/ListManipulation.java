import java.util.*;

class ListManipulation {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        for (int num : numbers) {
            System.out.println(num * num);
        }
    }
}
